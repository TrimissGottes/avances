"""Aqui van los formularios que se renderizan en los templates a traves de las views, el uso del framework se encarga de las
validaciones de entrada de datos"""

from django import forms
from django.contrib.auth.forms import AuthenticationForm, UserCreationForm
from .models import *

#Login
class UsuarioLoginForm(AuthenticationForm):
    username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Nombre de Usuario'}),label="")
    password=forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}),label="")

#Creacion de un usuario
class UsuarioRegistroForm(UserCreationForm):
    class Meta:
        model=Usuario
        fields=('first_name','last_name','email','rut','username')
    
    first_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Nombre'}),label="")    
    last_name=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Apellifo'}),label="")  
    email=forms.EmailField(widget=forms.EmailInput(attrs={'class':'form-control','placeholder':'Email'}),label="")  
    rut=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'rut'}),label="")
    username=forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Nombre de Usuario'}),label="")
    password1=forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Password'}),label="")
    password2=forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control','placeholder':'Confirmar Password'}),label="")

    #Guardar los cambios (nomedigas)
    def save(self,commit=True):
        usuario=super().save(commit=False)
        if commit:
            usuario.save()
            perfil=Perfil(usuario=usuario)
            perfil.save()
        return usuario

#modificar perfil de usuario
class ModificarUsuarioForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = ('first_name', 'last_name', 'email', 'rut')

    first_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Nombre'}), label="")
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Apellido'}), label="")
    email = forms.EmailField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Email'}), label="")
    rut = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'RUT'}), label="")
    username = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'readonly': 'readonly'}), label="")

#por si acaso para busquedas
class BuscarForm(forms.Form):
    query = forms.CharField(max_length=100, required=False, widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Buscar libro o usuario'}))


class LibroForm(forms.ModelForm):
    class Meta:
        model = Libro
        fields = '__all__'
