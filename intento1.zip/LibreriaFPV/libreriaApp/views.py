from django.shortcuts import render, redirect,get_object_or_404
from .models import *
from .forms import *
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.urls import reverse


# Create your views here.
def index(request):
    return render(request,'index.html')

def registrarse(request):
    form=UsuarioRegistroForm()
    if request.method=='POST':
        form=UsuarioRegistroForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  
    else:
        form=UsuarioRegistroForm()           
    return render(request,'registrarse.html',{'form':form})

@login_required(login_url='login')
def perfil(request):
    return render(request,'perfil.html')

#@login_required(login_url='login')
def perfil_admin(request):
    # Lógica para manejar las opciones de gestión según la opción seleccionada
    if request.method == 'GET':
        opcion_seleccionada = request.GET.get('opcion', None)
        if opcion_seleccionada:
            if opcion_seleccionada.startswith('libros'):
                return gestionar_libros(request, opcion_seleccionada)
            elif opcion_seleccionada.startswith('usuarios'):
                return gestionar_usuarios(request, opcion_seleccionada)
            elif opcion_seleccionada.startswith('reportes'):
                return gestionar_reportes(request, opcion_seleccionada)

    return render(request, 'perfilAdmin.html', {'opcion_seleccionada': None})

#busquedas
def buscar(request):
    form = BuscarForm(request.GET)
    query = form['query'].value()

    libros = Libro.objects.filter(titulo__icontains=query)
    usuarios = Usuario.objects.filter(username__icontains=query)

    return render(request, 'perfilAdmin.html', {'libros': libros, 'usuarios': usuarios, 'query': query, 'form': form})

#opciones de gestion de libros
def gestionar_libros(request, opcion):
    libros = Libro.objects.all()

    if opcion == 'listar_libros':
        return render(request, 'perfilAdmin.html', {'libros': libros, 'opcion_seleccionada': opcion})
    elif opcion == 'ingresar_libro':
        # Lógica para mostrar el formulario de ingreso de libro
        form = LibroForm(request.POST or None)
        if request.method == 'POST' and form.is_valid():
            form.save()
            return redirect('listar_libros')
        return render(request, 'perfilAdmin.html', {'form': form, 'opcion_seleccionada': opcion})
    elif opcion == 'modificar_libro':
        # Lógica para mostrar el formulario de modificación de libro
        if request.method == 'POST':
            id_libro = request.POST.get('libro_id')
            libro = get_object_or_404(Libro, idLibro=id_libro)
            form = LibroForm(request.POST, instance=libro)
            if form.is_valid():
                form.save()
                return redirect('listar_libros')
        else:
            id_libro = request.GET.get('libro_id')
            libro = get_object_or_404(Libro, idLibro=id_libro)
            form = LibroForm(instance=libro)
        return render(request, 'perfilAdmin.html', {'form': form, 'opcion_seleccionada': opcion})
    elif opcion == 'eliminar_libro':
        # Lógica para mostrar el formulario o mensaje de confirmación de eliminación
        if request.method == 'POST':
            id_libro = request.POST.get('libro_id')
            libro = get_object_or_404(Libro, idLibro=id_libro)
            libro.delete()
            return redirect('listar_libros')
        return render(request, 'perfilAdmin.html', {'libros': libros, 'opcion_seleccionada': opcion})
    else:
        return render(request, 'perfilAdmin.html', {'libros': libros, 'opcion_seleccionada': None})


#opciones de gestión de usuarios
def gestionar_usuarios(request, opcion):
    usuarios = Usuario.objects.all()

    if opcion == 'listar-usuarios':
        return render(request, 'perfilAdmin.html', {'usuarios': usuarios, 'opcion_seleccionada': opcion})
    elif opcion == 'modificar-usuario':
        # Lógica para mostrar el formulario de modificación de usuario
        if request.method == 'POST':
            username = request.POST.get('username')
            usuario = get_object_or_404(Usuario, username=username)
            form = UsuarioRegistroForm(request.POST, instance=usuario)
            if form.is_valid():
                form.save()
                return redirect('listar_usuarios')
        else:
            username = request.GET.get('username')
            usuario = get_object_or_404(Usuario, username=username)
            form = UsuarioRegistroForm(instance=usuario)
        return render(request, 'perfilAdmin.html', {'form': form, 'usuario': usuario, 'opcion_seleccionada': opcion})
    else:
        return render(request, 'perfilAdmin.html', {'usuarios': usuarios, 'opcion_seleccionada': None})



#gestion de reportes
def gestionar_reportes(request, opcion):

    if opcion == 'listar_reportes_pendientes':
        # Lógica para mostrar los reportes pendientes
        reportes_pendientes = Reporte.objects.filter(estadoReporte='PENDIENTE')
        return render(request, 'perfilAdmin.html', {'reportes_pendientes': reportes_pendientes, 'opcion_seleccionada': opcion})
    elif opcion == 'listar_reportes_resueltos':
        # Lógica para mostrar los reportes resueltos
        reportes_resueltos = Reporte.objects.filter(estadoReporte='RESUELTO')
        return render(request, 'perfilAdmin.html', {'reportes_resueltos': reportes_resueltos, 'opcion_seleccionada': opcion})
    elif opcion == 'listar_reportes_pendientes_publicaciones':
        # Lógica para mostrar los reportes pendientes sobre publicaciones
        reportes_pendientes_publicaciones = Reporte.objects.filter(estadoReporte='PENDIENTE', post__isnull=False)
        return render(request, 'perfilAdmin.html', {'reportes_pendientes_publicaciones': reportes_pendientes_publicaciones, 'opcion_seleccionada': opcion})
    elif opcion == 'listar_reportes_resueltos_publicaciones':
        # Lógica para mostrar los reportes resueltos sobre publicaciones
        reportes_resueltos_publicaciones = Reporte.objects.filter(estadoReporte='RESUELTO', post__isnull=False)
        return render(request, 'perfilAdmin.html', {'reportes_resueltos_publicaciones': reportes_resueltos_publicaciones, 'opcion_seleccionada': opcion})
    elif opcion == 'listar_reportes_pendientes_comentarios':
        # Lógica para mostrar los reportes pendientes sobre comentarios
        reportes_pendientes_comentarios = Reporte.objects.filter(estadoReporte='PENDIENTE', comentario__isnull=False)
        return render(request, 'perfilAdmin.html', {'reportes_pendientes_comentarios': reportes_pendientes_comentarios, 'opcion_seleccionada': opcion})
    elif opcion == 'listar_reportes_resueltos_comentarios':
        # Lógica para mostrar los reportes resueltos sobre comentarios
        reportes_resueltos_comentarios = Reporte.objects.filter(estadoReporte='RESUELTO', comentario__isnull=False)
        return render(request, 'perfilAdmin.html', {'reportes_resueltos_comentarios': reportes_resueltos_comentarios, 'opcion_seleccionada': opcion})
    else:
        return render(request, 'perfilAdmin.html', {'opcion_seleccionada': None})

def login_usuario(request):
    user_message=request.GET.get('message',None)  
    
    if request.method=="POST":
        form=UsuarioLoginForm(data=request.POST)
        
        if form.is_valid():
            username=form.cleaned_data.get('username')
            password=form.cleaned_data.get('password')
            user=authenticate(request,username=username,password=password)
            
            if user is not None:
                login(request,user)
                if user.is_superuser:
                    return redirect('perfiladmin')
                else:
                    return redirect('perfil')
            else:
                user_message="Usuario o contraseña incorrectos."
        else:
            user_message="Por favor, ingrese un usuario o contraseña válidos."
            
    else:
        form=UsuarioLoginForm()
        
    return render(request,'login.html',{'form':form,'user_message':user_message})

def cerrar_sesion(request):
    logout(request)
    return redirect(reverse('login')+"?message=Has cerrado sesión correctamente.")
